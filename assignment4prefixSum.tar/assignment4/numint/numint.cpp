#include <omp.h>
#include <stdio.h>
#include <chrono>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

using namespace std;

int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 9) {
    std::cerr<<"Usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }

  //insert code here

  int id = atoi(argv[1]);
  float a = atoi(argv[2]);
  float b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  omp_set_num_threads(atoi(argv[6]));
  string scheduling = argv[7];
  int granularity = atoi(argv[8]);

  if (scheduling == "static") {
    omp_set_schedule(omp_sched_static, granularity);
  }
  else if (scheduling == "dynamic") {
    omp_set_schedule(omp_sched_dynamic, granularity);
  } else {
    omp_set_schedule(omp_sched_guided, granularity);
  }

  chrono::time_point<chrono::system_clock> start = chrono::system_clock::now();

  float total = 0;

  switch(id) {
    case 1:
      #pragma omp parallel for schedule(runtime) reduction(+:total)
        for (int i = 0; i < n; i++) {
          total += f1(a + (i + .5) * ((b - a) / n), intensity);
        }
      total = total * ((b - a) / n);
      break;

    case 2:
      #pragma omp parallel for schedule(runtime) reduction(+:total)
        for (int i = 0; i < n; i++) {
          total += f2(a + (i + .5) * ((b - a) / n), intensity);
        }
      total = total * ((b - a) / n);
      break;

    case 3:
      #pragma omp parallel for schedule(runtime) reduction(+:total)
        for (int i = 0; i < n; i++) {
          total += f3(a + (i + .5) * ((b - a) / n), intensity);
        }
      total = total * ((b - a) / n);
      break;

    case 4:
      #pragma omp parallel for schedule(runtime) reduction(+:total)
        for (int i = 0; i < n; i++) {
          total += f4(a + (i + .5) * ((b - a) / n), intensity);
        }
      total = total * ((b - a) / n);
      break;
  }
  


  chrono::time_point<chrono::system_clock> end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end - start;

  cout << total << endl;
  cerr << elapsed_seconds.count() << endl;
  

  return 0;
}
