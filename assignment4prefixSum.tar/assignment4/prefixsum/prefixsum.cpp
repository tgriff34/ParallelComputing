#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>


#ifdef __cplusplus
extern "C" {
#endif
  void generatePrefixSumData (int* arr, size_t n);
  void checkPrefixSumResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif

using namespace std;

int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 3) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  
  int n = atoi(argv[1]);

  int * arr = new int [n];
  generatePrefixSumData (arr, n);

  int * pr = new int [n+1];

  //insert prefix sum code here
  
  //set num of threads
  int numberOfThreads = atoi(argv[2]);
  omp_set_num_threads(numberOfThreads);

  int numberOfChunks = n / numberOfThreads;
  int k = n % numberOfThreads;

  chrono::time_point<chrono::system_clock> start = chrono::system_clock::now();

  #pragma omp parallel for
    for (int i = 0; i < numberOfThreads; i++) {
      int min = i * numberOfChunks + 1;
      int max = 0;
      if (i == numberOfThreads - 1) {
        max = ((i+1) * numberOfChunks) + k;
      } else {
        max = ((i+1) * numberOfChunks);
      }
      pr[min] = arr[min - 1];
      for (int j = min; j < max; j++) {
        pr[j + 1] = pr[j] + arr[j];
      }
    }

  for (int i = 1; i < numberOfThreads; i++) {
    int numberToAdd = pr[i * numberOfChunks];
    int min = i * numberOfChunks + 1;
    int max = 0;
    if (i == numberOfThreads - 1) {
      max = ((i+1) * numberOfChunks) + k;
    } else {
      max = ((i+1) * numberOfChunks);
    }
    #pragma omp parallel for
      for (int j = min; j <= max; j++) {
	pr[j] += numberToAdd;
      }
  }

  chrono::time_point<chrono::system_clock> end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end - start;

  cerr << elapsed_seconds.count() << endl;
  
  checkPrefixSumResult(pr, n);

  delete[] arr;

  return 0;
}
