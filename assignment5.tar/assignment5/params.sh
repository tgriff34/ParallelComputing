#!/bin/bash

# common params
THREADS="1 2 4 8 12 16"

# reduce params
REDUCE_NS="10000 1000000 100000000" 

# mergesort params
MERGESORT_NS="10000 1000000 1000000000"

# bubblesort params
BUBBLESORT_NS="1000 10000 1000000"

# lcs params
LCS_NS="100 1000 100000" 
