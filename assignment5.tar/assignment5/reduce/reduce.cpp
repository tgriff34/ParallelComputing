#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>


#ifdef __cplusplus
extern "C" {
#endif

  void generateReduceData (int* arr, size_t n);

#ifdef __cplusplus
}
#endif

using namespace std;

int subtask(int arr[], int start, int end) {
  int ans = 0;
  int difference = end - start;
  //cout << "Start: " << start << " , End : " << end << endl;
  if (start == end) {
    return start;
  }
  if (end - start <= 3) {
    int j = 0;
    for (int i = start; i <= end; i++) {
      //cout << "Value at i: " << i << " is " << arr[i] << endl;
      j += arr[i];
    }
    //cout << "Divided enough, answer is: " << j << endl;
    return j;
  } else {
    int k = difference % 2;
    //cout << "K: " << k << endl;
    int newStart;
    if (k != 0) {
      newStart = start + (difference / 2) + k;
    } else {
      newStart = start + (difference / 2) + 1;
    }
    int newEnd = newStart - 1;
    /*
    cout << "Start: " << start << endl;
    cout << "New End: " << newEnd << endl;
    cout << "New Start: " << newStart << endl;
    cout << "End: " << end << endl;
    */
    #pragma omp task shared(ans)
    {
      ans += subtask(arr, start, newEnd);
    }
    #pragma omp task shared(ans)
    {
      ans += subtask(arr, newStart, end);
    }
    #pragma omp taskwait
  }
  //cout << "Answer from " << start << " to " << end << " is " << ans << endl;
  return ans;
}


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 3) {
    std::cerr<<"usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int * arr = new int [n];
  int nbthreads = atoi(argv[2]);

  generateReduceData (arr, atoi(argv[1]));
  omp_set_num_threads(nbthreads);

  //insert reduction code here
  chrono::time_point<chrono::system_clock> start = chrono::system_clock::now();
  /*
  for (int i = 0; i < n; i++) {
    cout << arr[i] << ", ";
  }
  cout << endl;
  */
  int ans;
  #pragma omp parallel
  {
    int numberOfChunks = n / nbthreads;
    int k = n % nbthreads;
    #pragma omp for
    for (int i = 0; i < nbthreads; i++) {
      //cout << "Thread number: " << i << endl;
      int min = i * numberOfChunks;
      int max = 0;
      if (i == nbthreads - 1 && k != 0) {
        max = ((i+1) * numberOfChunks) - 1 + k;
      } else {
        max = ((i+1) * numberOfChunks) - 1;
      }
      //cout << "MIN: " << min << endl;
      //cout << "MAX: " << max << endl;
      #pragma omp task shared(ans)
      {
        ans += subtask(arr, min, max);
	//cout << "Thread " << i << " ans: " << ans << endl;
      }
    }
  }


  chrono::time_point<chrono::system_clock> end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end - start;

  cout << ans << endl;
  cerr << elapsed_seconds.count() << endl;
  
  delete[] arr;

  return 0;
}
