#include <mpi.h>
#include <unistd.h>
#include <limits.h>
#include <iostream>

using namespace std;

int main(int argc, char*argv[]) {
    int size, rank;

    char hostname[HOST_NAME_MAX];

    gethostname(hostname, HOST_NAME_MAX);

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    cout << "I am process " << rank << " out of " << size << "." 
	    << " I am running on " << hostname << "." << endl;

    MPI_Finalize();

    return 0;
}
