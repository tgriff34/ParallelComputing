#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
#include <mpi.h>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

using namespace std;
  
int main (int argc, char* argv[]) {
  
  if (argc < 6) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }
  
  int i = atoi(argv[1]);
  float a = atoi(argv[2]);
  float b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);

  int size, rank;
  
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  chrono::time_point<chrono::system_clock> start = chrono::system_clock::now();

  float combinedTotal;
  float total = 0;
  switch(i) {
    case 1: 
      for (int i = rank; i < n; i += size) {
        total += f1(a + (i + .5) * ((b - a) / n), intensity); 
      }
      total = total * ((b - a) / n);
      MPI_Reduce(&total, &combinedTotal, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
      break;
    case 2: 
      for (int i = rank; i < n; i += size) {
        total += f2(a + (i + .5) * ((b - a) / n), intensity); 
      }
      total = total * ((b - a) / n);
      MPI_Reduce(&total, &combinedTotal, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
      break;
    case 3: 
      for (int i = rank; i < n; i += size) {
        total += f3(a + (i + .5) * ((b - a) / n), intensity); 
      }
      total = total * ((b - a) / n);
      MPI_Reduce(&total, &combinedTotal, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
      break;
    case 4: 
      for (int i = rank; i < n; i += size) {
        total += f4(a + (i + .5) * ((b - a) / n), intensity); 
      }
      total = total * ((b - a) / n);
      MPI_Reduce(&total, &combinedTotal, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
      break;

  }

  chrono::time_point<chrono::system_clock> end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end - start;

  if (rank == 0) {
    cout << combinedTotal << endl;
    cerr << elapsed_seconds.count() << endl;
  }

  MPI_Finalize();

  return 0;
}
