#include <mpi.h>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <chrono>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

using namespace std;

int main (int argc, char* argv[]) {

  if (argc < 6) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }

  //cout << "test" << endl;

  int id = atoi(argv[1]);
  float a = atoi(argv[2]);
  float b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);

  int granularity = (n / (n / 100));

  int rank, size;


  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);


  chrono::time_point<chrono::system_clock> time_start = chrono::system_clock::now();

  if (rank == 0) {
    bool _done = false;
    int _work = 0, start, end, done = 0;
    float sum = 0;

    do {
      int _iterations = 1;
      for (int i = 1; i < size; i++) {
        if (!_done) {
	  start = _work;
	  end = _work + granularity - 1;

	  //cout << "Size: " << size << endl;
	  //cout << "Sending start: " << start << " and end: " << end << " to " << i << endl;
	  MPI_Send(&done, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
	  MPI_Send(&start, 1, MPI_INT, i, 0, MPI_COMM_WORLD); 
	  MPI_Send(&end, 1, MPI_INT, i, 0, MPI_COMM_WORLD); 

	  _work = _work + granularity;
	  _iterations++;

	  if (_work == n) {
            _done = true;
	    done = 1;
	  }
	}
      }
      for (int i = 1; i < _iterations; i++) {
	 float local_total = 0;
	 MPI_Recv(&local_total, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	 //cout << "MASTER TOTAL RECV: " << local_total << endl;
	 sum = sum + local_total;
	 //cout << "MASTER NEW SUM: " << sum << endl;
      }

      if (done == 1) { 
        for (int i = 1; i < size; i++) {
          MPI_Send(&done, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
      }
    } while(!_done);

    chrono::time_point<chrono::system_clock> time_end = chrono::system_clock::now();
    chrono::duration<double> elapsed_seconds = time_end - time_start;

    //int roundedoutput = elapsed_seconds.count();
    std::cout << sum << std::endl;
    std::cerr << elapsed_seconds.count() << std::endl;

  } else {
    int done;
    do {
      float _total = 0;
      int _start, _end;
      MPI_Recv(&done, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      //cout << "TASK DONE: " << done << endl;
      if (done == 0) {
        MPI_Recv(&_start, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&_end, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	//cout << "TASK START: " << _start << endl;
	//cout << "TASK END: " << _end << endl;
        switch(id) {
	  case 1:
            for (int i = _start; i <= _end; i++) {
              _total += f1(a + (i + .5) * ((b - a) / n), intensity);
            }
            _total = _total * ((b - a) / n);
	    break;
	  case 2:
            for (int i = _start; i <= _end; i++) {
              _total += f2(a + (i + .5) * ((b - a) / n), intensity);
            }
            _total = _total * ((b - a) / n);
	    break;
	  case 3:
            for (int i = _start; i <= _end; i++) {
              _total += f3(a + (i + .5) * ((b - a) / n), intensity);
            }
            _total = _total * ((b - a) / n);
	    break;
	  case 4:
            for (int i = _start; i <= _end; i++) {
              _total += f4(a + (i + .5) * ((b - a) / n), intensity);
            }
            _total = _total * ((b - a) / n);
	    break;
        }
	//cout << "TASK SENDING TOTAL: " << _total << endl;
        MPI_Send(&_total, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
      }
    } while(done == 0);
  }

  MPI_Finalize();

  return 0;
}
