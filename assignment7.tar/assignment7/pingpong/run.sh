#!/bin/sh

mpirun ./mpi_ping_pong 3 
