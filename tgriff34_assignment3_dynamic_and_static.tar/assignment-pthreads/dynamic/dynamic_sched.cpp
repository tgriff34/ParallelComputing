#include <iostream>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

using namespace std;

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);
pthread_mutex_t mut, mut2;
int nbPassThroughs = 0;
int k = 0;
float total = 0;

#ifdef __cplusplus
}
#endif

struct Data {
  int function;
  int a;
  int b;
  int n;
  int intensity;
  int granularity;
  int nbIterations;
  string sync;
};

void* f (void* p) {
  struct Data *input = (struct Data*)p;
  float y = ((float)(input->b - input->a) / (float)input->n);
  float min, max, threadTotal;
  bool doWork = true;

  while(doWork) {
    //get min and max
    pthread_mutex_lock(&mut2);
    if (::nbPassThroughs < input->nbIterations) {
      min = ::nbPassThroughs * input->granularity;
      max = ((::nbPassThroughs + 1) * input->granularity) - 1;
      ::nbPassThroughs++;
      pthread_mutex_unlock(&mut2);

      //compute
      float x = 0;
      float total = 0;
      switch(input->function) {
        case 1:
          for (int i = min; i <= max; i++) {
            x = (input->a + (i + .5));
	    if (input->sync == "chunk" || input->sync == "thread") {
              total = total + (y * f1(x * y, input->intensity));
	    }
	    else {
              pthread_mutex_lock(&mut);
	      ::total = ::total + (y * f1(x * y, input->intensity));
              pthread_mutex_unlock(&mut);
	    }
          }
	  if (input->sync == "chunk") {
            pthread_mutex_lock(&mut);
            ::total = ::total + total;
            pthread_mutex_unlock(&mut);
	  }
	  else if (input->sync == "thread") {
            threadTotal = threadTotal + total;
	  }
	  break;

	case 2:
          for (int i = min; i <= max; i++) {
            x = (input->a + (i + .5));
	    if (input->sync == "chunk" || input->sync == "thread") {
              total = total + (y * f2(x * y, input->intensity));
	    }
	    else {
              pthread_mutex_lock(&mut);
	      ::total = ::total + (y * f2(x * y, input->intensity));
              pthread_mutex_unlock(&mut);
	    }
          }
	  if (input->sync == "chunk") {
            pthread_mutex_lock(&mut);
            ::total = ::total + total;
            pthread_mutex_unlock(&mut);
	  }
	  else if (input->sync == "thread") {
            threadTotal = threadTotal + total;
	  }
	  break;

	case 3:
          for (int i = min; i <= max; i++) {
            x = (input->a + (i + .5));
	    if (input->sync == "chunk" || input->sync == "thread") {
              total = total + (y * f3(x * y, input->intensity));
	    }
	    else {
              pthread_mutex_lock(&mut);
	      ::total = ::total + (y * f3(x * y, input->intensity));
              pthread_mutex_unlock(&mut);
	    }
          }
	  if (input->sync == "chunk") {
            pthread_mutex_lock(&mut);
            ::total = ::total + total;
            pthread_mutex_unlock(&mut);
	  }
	  else if (input->sync == "thread") {
            threadTotal = threadTotal + total;
	  }
	  break;

	case 4:
          for (int i = min; i <= max; i++) {
            x = (input->a + (i + .5));
	    if (input->sync == "chunk" || input->sync == "thread") {
              total = total + (y * f4(x * y, input->intensity));
	    }
	    else {
              pthread_mutex_lock(&mut);
	      ::total = ::total + (y * f4(x * y, input->intensity));
              pthread_mutex_unlock(&mut);
	    }
          }
	  if (input->sync == "chunk") {
            pthread_mutex_lock(&mut);
            ::total = ::total + total;
            pthread_mutex_unlock(&mut);
	  }
	  else if (input->sync == "thread") {
            threadTotal = threadTotal + total;
	  }
	  break;
      }
    } else {
      pthread_mutex_unlock(&mut2);
      if (input->sync == "thread") {
        pthread_mutex_lock(&mut);
        ::total = ::total + threadTotal;
        pthread_mutex_unlock(&mut);
      }
      doWork = false;
    }
  }
  return NULL;
}

int main (int argc, char* argv[]) {

  chrono::time_point<chrono::system_clock> start = chrono::system_clock::now();

  if (argc < 9) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync> <granularity>"<<std::endl;
    return -1;
  }

  int id = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  int nbthreads = atoi(argv[6]);
  string sync = argv[7];
  int granularity = atoi(argv[8]);

  pthread_mutex_init(&mut, NULL);
  pthread_mutex_init(&mut2, NULL);
  Data *input = new Data[nbthreads];
  pthread_t threads[nbthreads];
  int nbIterations;
  if (n % granularity != 0) {
    ::k = n % granularity;
    nbIterations = n / granularity;
  } else {
    nbIterations = n / granularity;
  }

  for (int i = 0; i < nbthreads; i++) {
    input[i].function = id;
    input[i].a = a;
    input[i].b = b;
    input[i].n = n;
    input[i].intensity = intensity;
    input[i].sync = sync;
    input[i].granularity = granularity;
    input[i].nbIterations = nbIterations;
    pthread_create(&threads[i], NULL, f, (void *)&input[i]);
  }
  for (int i = 0; i < nbthreads; i++) {
    pthread_join(threads[i], NULL);
  }

  pthread_mutex_destroy(&mut);
  pthread_mutex_destroy(&mut2);

  chrono::time_point<chrono::system_clock> end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end - start;

  cout << ::total << endl;
  cerr << elapsed_seconds.count() << endl;

  return 0;
}
