#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

struct Data{
  int i;
  int n;
};

void* f(void* p) {
  struct Data *input = (struct Data*)p;
  printf("I am thread %d of %d\n", input->i, input->n);
  return NULL;
}

int main (int argc, char* argv[]) {

  int nbthreads = atoi(argv[1]);
  pthread_t threads[nbthreads];

  struct Data input;
  input.n = nbthreads;

  if (argc < 2) {
    std::cerr<<"usage: "<<argv[0]<<" <nbthreads>"<<std::endl;
    return -1;
  }

  for (int i = 0; i < nbthreads; ++i) {
    input.i = i;
    pthread_create(&threads[i], NULL, f, (void *)&input);
    pthread_join(threads[i], NULL);
  }

  return 0;
}

