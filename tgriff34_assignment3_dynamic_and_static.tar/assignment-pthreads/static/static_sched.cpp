#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include <cmath>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);
pthread_mutex_t mut;
float total = 0;

#ifdef __cplusplus
}
#endif

struct Data {
  int function;
  int min;
  int max;
  int a;
  int b;
  int n;
  int intensity;
  string sync;
};

void* f(void* p) {
  struct Data *input = (struct Data*)p;
  float total = 0;
  float x = 0;
  float y = ((float)(input->b - input->a) / (float)input->n);
  switch(input->function) {
    case 1:
      for (int i = input->min; i <= input->max; i++) {
        x = (input->a + (i + .5));
	if (input->sync == "thread") {
          total = total + (y * f1(x * y, input->intensity));
	} else {
          pthread_mutex_lock(&mut);
          ::total = ::total + (y * f1(x * y, input->intensity));
          pthread_mutex_unlock(&mut);
	}
      }
      if (input->sync == "thread") {
        pthread_mutex_lock(&mut);
        ::total = ::total + total;
        pthread_mutex_unlock(&mut);
      }
      break;

    case 2:
      for (int i = input->min; i <= input->max; i++) {
        x = (input->a + (i + .5));
	if (input->sync == "thread") {
          total = total + (y * f2(x * y, input->intensity));
	} else {
          pthread_mutex_lock(&mut);
          ::total = ::total + (y * f2(x * y, input->intensity));
          pthread_mutex_unlock(&mut);
	}
      }
      if (input->sync == "thread") {
        pthread_mutex_lock(&mut);
        ::total = ::total + total;
        pthread_mutex_unlock(&mut);
      }

      break;

    case 3:
      for (int i = input->min; i <= input->max; i++) {
        x = (input->a + (i + .5));
	if (input->sync == "thread") {
          total = total + (y * f3(x * y, input->intensity));
	} else {
          pthread_mutex_lock(&mut);
          ::total = ::total + (y * f3(x * y, input->intensity));
          pthread_mutex_unlock(&mut);
	}
      }
      if (input->sync == "thread") {
        pthread_mutex_lock(&mut);
        ::total = ::total + total;
        pthread_mutex_unlock(&mut);
      }

      break;

    case 4:
      for (int i = input->min; i <= input->max; i++) {
        x = (input->a + (i + .5));
	if (input->sync == "thread") {
          total = total + (y * f4(x * y, input->intensity));
	} else {
          pthread_mutex_lock(&mut);
          ::total = ::total + (y * f4(x * y, input->intensity));
          pthread_mutex_unlock(&mut);
	}
      }
      if (input->sync == "thread") {
        pthread_mutex_lock(&mut);
        ::total = ::total + total;
        pthread_mutex_unlock(&mut);
      }

      break;
  }
  return NULL;
}


int main (int argc, char* argv[]) {

  chrono::time_point<chrono::system_clock> start = chrono::system_clock::now();

  if (argc < 8) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync>"<<std::endl;
    return -1;
  }

  int id = atoi(argv[1]);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  int nbthreads = atoi(argv[6]);
  string sync = argv[7];

  pthread_t threads[nbthreads];

  Data *input = new Data[nbthreads];

  int k = 0;
  int nbIterations;
  if (n % nbthreads != 0) {
    k = n % nbthreads;
    nbIterations = n / nbthreads;
  } else {
    nbIterations = n / nbthreads;
  }
  pthread_mutex_init(&mut, NULL);
  for (int i = 0; i < nbthreads; i++) {
    input[i].function = id;
    input[i].a = a;
    input[i].b = b;
    input[i].n = n;
    input[i].intensity = intensity;
    input[i].min = i * nbIterations;
    int j = i + 1;
    if (n % nbthreads != 0 && i == nbthreads - 1) {
      input[i].max = (j * nbIterations) - 1 + k;
    } else {
      input[i].max = (j * nbIterations) - 1;
    }
    input[i].sync = sync;
    pthread_create(&threads[i], NULL, f, (void *)&input[i]);
  }
  for (int i = 0; i < nbthreads; i++) {
    pthread_join(threads[i], NULL);
  }

  pthread_mutex_destroy(&mut);

  chrono::time_point<chrono::system_clock> end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end - start;

  cout<< ::total << endl;
  cerr<< elapsed_seconds.count() << endl;
  

  return 0;
}
